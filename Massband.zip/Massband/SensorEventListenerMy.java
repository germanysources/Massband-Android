package Massband.com;
import android.hardware.SensorEventListener;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import java.util.*;
import android.util.Log;

class SensorEventListenerMy implements SensorEventListener{
    protected long timestamp; 
    final float nanoumr = 1E-9f;
    protected float[] max_rot;
    protected float[] ist_rot;
    List<float[]> valb;
    public mass corf_mass;
    public boolean rc_calib;
    protected Object warte;//Wird nach dem Kalibrieren mit Object.notify() benachrichtigt
    protected int zaehler;
    private final static int maxzaehler = 200;
    public SensorEventListenerMy(float[] max_rot, String action, float[] add){
	timestamp = 0;	
	rc_calib = false;
	this.max_rot = max_rot;
	ist_rot = new float[3];
	valb = new ArrayList<float[]>();
	float init_a[] = {0, 0, 0};
	valb.add(init_a);
	corf_mass = new mass(action, add);
	warte = null;
	zaehler = 0;
    }
    public SensorEventListenerMy(float[] max_rot, String action, float[] add, Object w){
	timestamp = 0;	
	rc_calib = false;
	this.max_rot = max_rot;
	ist_rot = new float[3];
	valb = new ArrayList<float[]>();
	float init_a[] = {0, 0, 0};
	valb.add(init_a);
	corf_mass = new mass(action, add);
	warte = w;
	zaehler = 0;
    }
    public void onSensorChanged(SensorEvent event)
    throws RuntimeException{
	float del_time = (event.timestamp - timestamp)*nanoumr;
	timestamp = event.timestamp;
	       Log.d("gui_massb", timestamp + "\t" + System.currentTimeMillis());
	if(event.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
	    valb.add(event.values);
	    if(corf_mass.action.equals(mass.CALIB)){
		corf_mass.calibs(valb, del_time);
		zaehler++;
		Log.d("gui_massb", "zaehler: " + zaehler);
		if(zaehler > maxzaehler){
		   // synchronized(warte){
		      corf_mass.action = "";
		      // warte.notify();
		   // }
		}
	    }
	    else{
		corf_mass.inte_beschl(valb, del_time);
	    }
	    if(corf_mass.action.equals(mass.CALIB)){
		for(int i = 0; i<3; i++){
		    if(Math.abs(corf_mass.distance[i]) > max_rot[1]){
		       rc_calib = true;
		    }
		}
	    }

	}
	else{
	   if(corf_mass.action.equals(mass.CALIB)){
		ist_rot[0] += event.values[0] * del_time;
		ist_rot[1] += event.values[1] * del_time;
		ist_rot[2] += event.values[2] * del_time;
		for(int i = 0;i<3;i++){
		   if(Math.abs(ist_rot[i]) > max_rot[i]){
		      rc_calib = true;
		   }
		}
	    }
	    else{
		corf_mass.dreh(event.values, del_time);
	    }
	}
	
    }
    public void onAccuracyChanged(Sensor sensor, int accuracy){
	
    }
   public synchronized void write_calib(Context context) throws FileNotFoundException, IOException{
      // Kalibrierungsdaten auf interal Storage speichern
      // Integral - g (add), und Integral(Messwert-g)^2 (err) und daraus Wurzel
      
      StringBuilder filecon = new StringBuilder();
      for(int i = 0;i < add.length; i++) {
	 filecon.append(add[i]);
	 filecon.append(trenn);
      }
      for(int i = 0;i < err.length; i++) {
	 filecon.append(err[i]);
	 filecon.append(trenn);
      }      
      FileOutputStream outputStream;
	       
      outputStream = context.openFileOutput(filename, Context.MODE_PRIVATE);
      outputStream.write(filecon.toString().getBytes());
      outputStream.close();
   }
   

}
