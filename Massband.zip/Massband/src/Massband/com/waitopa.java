package com.Massband;
public abstract class waitopa{
    public abstract void mess_end();
}
